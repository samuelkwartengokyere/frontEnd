// script.js

// ==========================================
// CONFIGURATION: Replace with your EmailJS keys
// ==========================================
const EMAILJS_PUBLIC_KEY = "YOUR_PUBLIC_KEY"; 
const EMAILJS_SERVICE_ID = "YOUR_SERVICE_ID"; 
const EMAILJS_TEMPLATE_ID = "YOUR_TEMPLATE_ID"; 

// Initialize EmailJS
(function() {
    emailjs.init({ publicKey: EMAILJS_PUBLIC_KEY });
})();

const form = document.getElementById('emailForm');
const sendBtn = document.getElementById('sendBtn');
const progressContainer = document.getElementById('progressContainer');
const progressBarFill = document.getElementById('progressBarFill');
const statusText = document.getElementById('statusText');

// Helper function to create a delay (Throttling)
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// Helper to validate email format
const isValidEmail = (email) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
};

form.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    // 1. Gather and parse data
    const rawRecipients = document.getElementById('recipients').value;
    const subject = document.getElementById('subject').value;
    const message = document.getElementById('message').value;

    // Split by comma or newline, trim whitespace, remove empty strings
    const emailList = rawRecipients
        .split(/[\n,]+/)
        .map(email => email.trim())
        .filter(email => email.length > 0);

    // 2. Validate emails
    const validEmails = [];
    const invalidEmails = [];

    emailList.forEach(email => {
        if (isValidEmail(email)) {
            validEmails.push(email);
        } else {
            invalidEmails.push(email);
        }
    });

    if (validEmails.length === 0) {
        alert("No valid email addresses found.");
        return;
    }

    if (invalidEmails.length > 0) {
        console.warn("Skipped invalid emails:", invalidEmails);
    }

    // 3. UI Updates & Sending Process
    sendBtn.disabled = true;
    sendBtn.innerText = "Sending...";
    progressContainer.classList.remove('hidden');
    
    let successCount = 0;
    let failCount = 0;

    for (let i = 0; i < validEmails.length; i++) {
        const currentEmail = validEmails[i];
        const progress = ((i + 1) / validEmails.length) * 100;
        
        progressBarFill.style.width = `${progress}%`;
        statusText.innerText = `Sending to ${currentEmail}... (${i + 1}/${validEmails.length})`;

        try {
            // Send via EmailJS
            // Note: Your EmailJS template must have variables like {{to_email}}, {{subject}}, {{message}}
            await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, {
                to_email: currentEmail,
                subject: subject,
                message: message,
                reply_to: "your-verified-email@domain.com" // Must be verified in EmailJS
            });
            successCount++;
        } catch (error) {
            console.error(`Failed to send to ${currentEmail}:`, error);
            failCount++;
        }

        // THROTTLE: Wait 1.5 seconds between emails to avoid rate limits/spam filters
        if (i < validEmails.length - 1) {
            await sleep(1500); 
        }
    }

    // 4. Finalize
    statusText.innerText = `Campaign Complete! ✅ Sent: ${successCount} | ❌ Failed: ${failCount}`;
    progressBarFill.style.width = `100%`;
    sendBtn.disabled = false;
    sendBtn.innerText = "Send Another Campaign";
});